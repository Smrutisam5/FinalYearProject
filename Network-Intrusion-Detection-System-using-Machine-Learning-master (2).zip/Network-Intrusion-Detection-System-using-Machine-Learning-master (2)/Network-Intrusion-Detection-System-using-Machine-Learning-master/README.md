# Network-Intrusion-Detection-System-using-Machine-Learning
In this implementation, presented the performances of different classifier algorithms of machine learning to identified risks speedily and accurately.

One of the most dangerous aspects that the computer world glimpses are threats to security.
It estimated that about 3 billion dollars in cybercrime lost each year. It expected that
this figure would double by 2021. With all these threats loitering around, it is difficult
to track and eliminate all risks, especially when the number of users is increasing exponentially.
In this Implementation, presents the performances of different techniques to
identified risks speedily using machine learning for network intrusion detection system.
The main idea is to take the benefit of pyGAM and random forest classifier. pyGAM
is a package for building Generalized Additive Models in Python, with an emphasis on
modularity and performance. Random forest classifier used for attributes selection of
datasets. Employ data from the third international knowledge discovery and data mining
tools competition (NSL-KDD) to train and test the feasibility of our hybrid model. In
this paper, experiments have performed with different algorithms like Random Forest,
SVC, KNN, Na¨ıve Bayes, and LogisticGAM. For feature attribute selection we applied
Random forest Classifier. And additionally, I combined Random Forest and KNN as
model 1 classifier and Random Forest and Naive Bayes as model 2 classifier.
